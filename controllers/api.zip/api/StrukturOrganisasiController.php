<?php

namespace app\controllers\api;

/**
* This is the class for REST controller "StrukturOrganisasiController".
*/

use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;

class StrukturOrganisasiController extends \yii\rest\ActiveController
{
public $modelClass = 'app\models\StrukturOrganisasi';
}
