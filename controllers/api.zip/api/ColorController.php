<?php

namespace app\controllers\api;

/**
* This is the class for REST controller "ColorController".
*/

use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;

class ColorController extends \yii\rest\ActiveController
{
public $modelClass = 'app\models\Color';
}
