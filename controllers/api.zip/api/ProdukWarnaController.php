<?php

namespace app\controllers\api;

/**
* This is the class for REST controller "ProdukWarnaController".
*/

use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;

class ProdukWarnaController extends \yii\rest\ActiveController
{
public $modelClass = 'app\models\ProdukWarna';
}
