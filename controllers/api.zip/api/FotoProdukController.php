<?php

namespace app\controllers\api;

/**
* This is the class for REST controller "FotoProdukController".
*/

use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;

class FotoProdukController extends \yii\rest\ActiveController
{
public $modelClass = 'app\models\FotoProduk';
}
